let web3;
let ownerInstance, dealerInstance, vehicleRegInstance;

// Smart contract ABIs and addresses (Replace these with your actual ABIs and contract addresses)
const ownerABI = [
    {
      "inputs": [
        {
          "internalType": "address",
          "name": "_dealerAddress",
          "type": "address"
        },
        {
          "internalType": "address",
          "name": "_registrationAgencyAddress",
          "type": "address"
        }
      ],
      "stateMutability": "nonpayable",
      "type": "constructor"
    },
    {
      "inputs": [],
      "name": "dealerContract",
      "outputs": [
        {
          "internalType": "contract Dealer",
          "name": "",
          "type": "address"
        }
      ],
      "stateMutability": "view",
      "type": "function",
      "constant": true
    },
    {
      "inputs": [],
      "name": "ownerAddress",
      "outputs": [
        {
          "internalType": "address",
          "name": "",
          "type": "address"
        }
      ],
      "stateMutability": "view",
      "type": "function",
      "constant": true
    },
    {
      "inputs": [],
      "name": "registrationAgencyContract",
      "outputs": [
        {
          "internalType": "contract VehicleRegistrationAgency",
          "name": "",
          "type": "address"
        }
      ],
      "stateMutability": "view",
      "type": "function",
      "constant": true
    },
    {
      "inputs": [
        {
          "internalType": "uint256",
          "name": "vehicleId",
          "type": "uint256"
        },
        {
          "internalType": "string",
          "name": "ownerName",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "district",
          "type": "string"
        }
      ],
      "name": "registerVehicle",
      "outputs": [],
      "stateMutability": "nonpayable",
      "type": "function"
    }
  ];
const dealerABI = [
    {
      "inputs": [],
      "stateMutability": "nonpayable",
      "type": "constructor"
    },
    {
      "inputs": [
        {
          "internalType": "uint256",
          "name": "",
          "type": "uint256"
        }
      ],
      "name": "vehicles",
      "outputs": [
        {
          "internalType": "string",
          "name": "model",
          "type": "string"
        },
        {
          "internalType": "uint256",
          "name": "price",
          "type": "uint256"
        },
        {
          "internalType": "string",
          "name": "fuelType",
          "type": "string"
        },
        {
          "internalType": "uint256",
          "name": "yearOfManufacture",
          "type": "uint256"
        },
        {
          "internalType": "string",
          "name": "engineNumber",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "chassisNumber",
          "type": "string"
        },
        {
          "internalType": "uint256",
          "name": "seatingCapacity",
          "type": "uint256"
        },
        {
          "internalType": "uint256",
          "name": "unladenWeight",
          "type": "uint256"
        },
        {
          "internalType": "string",
          "name": "color",
          "type": "string"
        }
      ],
      "stateMutability": "view",
      "type": "function",
      "constant": true
    },
    {
      "inputs": [
        {
          "internalType": "uint256",
          "name": "vehicleId",
          "type": "uint256"
        }
      ],
      "name": "getVehicleDetails",
      "outputs": [
        {
          "components": [
            {
              "internalType": "string",
              "name": "model",
              "type": "string"
            },
            {
              "internalType": "uint256",
              "name": "price",
              "type": "uint256"
            },
            {
              "internalType": "string",
              "name": "fuelType",
              "type": "string"
            },
            {
              "internalType": "uint256",
              "name": "yearOfManufacture",
              "type": "uint256"
            },
            {
              "internalType": "string",
              "name": "engineNumber",
              "type": "string"
            },
            {
              "internalType": "string",
              "name": "chassisNumber",
              "type": "string"
            },
            {
              "internalType": "uint256",
              "name": "seatingCapacity",
              "type": "uint256"
            },
            {
              "internalType": "uint256",
              "name": "unladenWeight",
              "type": "uint256"
            },
            {
              "internalType": "string",
              "name": "color",
              "type": "string"
            }
          ],
          "internalType": "struct Dealer.Vehicle",
          "name": "",
          "type": "tuple"
        }
      ],
      "stateMutability": "view",
      "type": "function",
      "constant": true
    }
  ];
const vehicleRegABI = [
    {
      "inputs": [],
      "stateMutability": "nonpayable",
      "type": "constructor"
    },
    {
      "inputs": [
        {
          "internalType": "address",
          "name": "",
          "type": "address"
        }
      ],
      "name": "rcBooks",
      "outputs": [
        {
          "internalType": "string",
          "name": "ownerName",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "vehicleModel",
          "type": "string"
        },
        {
          "internalType": "uint256",
          "name": "vehiclePrice",
          "type": "uint256"
        },
        {
          "internalType": "string",
          "name": "fuelType",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "vehicleNumber",
          "type": "string"
        },
        {
          "internalType": "uint256",
          "name": "yearOfManufacture",
          "type": "uint256"
        },
        {
          "internalType": "string",
          "name": "engineNumber",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "chassisNumber",
          "type": "string"
        },
        {
          "internalType": "uint256",
          "name": "seatingCapacity",
          "type": "uint256"
        },
        {
          "internalType": "uint256",
          "name": "unladenWeight",
          "type": "uint256"
        },
        {
          "internalType": "string",
          "name": "color",
          "type": "string"
        }
      ],
      "stateMutability": "view",
      "type": "function",
      "constant": true
    },
    {
      "inputs": [
        {
          "internalType": "string",
          "name": "",
          "type": "string"
        }
      ],
      "name": "regionLetterCodes",
      "outputs": [
        {
          "internalType": "string",
          "name": "",
          "type": "string"
        }
      ],
      "stateMutability": "view",
      "type": "function",
      "constant": true
    },
    {
      "inputs": [
        {
          "internalType": "string",
          "name": "",
          "type": "string"
        }
      ],
      "name": "regionSerialNumbers",
      "outputs": [
        {
          "internalType": "uint256",
          "name": "",
          "type": "uint256"
        }
      ],
      "stateMutability": "view",
      "type": "function",
      "constant": true
    },
    {
      "inputs": [
        {
          "internalType": "string",
          "name": "",
          "type": "string"
        }
      ],
      "name": "vehicleOwners",
      "outputs": [
        {
          "internalType": "address",
          "name": "",
          "type": "address"
        }
      ],
      "stateMutability": "view",
      "type": "function",
      "constant": true
    },
    {
      "inputs": [
        {
          "internalType": "string",
          "name": "ownerName",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "vehicleModel",
          "type": "string"
        },
        {
          "internalType": "uint256",
          "name": "vehiclePrice",
          "type": "uint256"
        },
        {
          "internalType": "string",
          "name": "fuelType",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "district",
          "type": "string"
        },
        {
          "internalType": "uint256",
          "name": "yearOfManufacture",
          "type": "uint256"
        },
        {
          "internalType": "string",
          "name": "engineNumber",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "chassisNumber",
          "type": "string"
        },
        {
          "internalType": "uint256",
          "name": "seatingCapacity",
          "type": "uint256"
        },
        {
          "internalType": "uint256",
          "name": "unladenWeight",
          "type": "uint256"
        },
        {
          "internalType": "string",
          "name": "color",
          "type": "string"
        }
      ],
      "name": "authenticateOwnerAndAssignNumber",
      "outputs": [],
      "stateMutability": "nonpayable",
      "type": "function"
    }
  ];

const ownerContractAddress = "0xC6D085BF6ADD1e1c395C2cDFBf40675E8C8BF7B8";  // Replace with deployed Owner contract address
const dealerContractAddress = "0x1ca7caA64c399ad838714544c2040696d715b9e7";  // Replace with deployed Dealer contract address
const vehicleRegContractAddress = "0xc9233bd95bd682e035d82aaCdBCa2AA19CfD2771";  // Replace with deployed Vehicle Registration Agency contract address

// Load Web3 and connect to MetaMask
async function loadWeb3() {
    if (window.ethereum) {
        web3 = new Web3(window.ethereum);
        await window.ethereum.request({ method: 'eth_requestAccounts' });
        console.log("Connected to MetaMask");
        initializeContracts();
    } else {
        alert("Please install MetaMask to use this application.");
    }
}

// Initialize contract instances
function initializeContracts() {
    ownerInstance = new web3.eth.Contract(ownerABI, ownerContractAddress);
    dealerInstance = new web3.eth.Contract(dealerABI, dealerContractAddress);
    vehicleRegInstance = new web3.eth.Contract(vehicleRegABI, vehicleRegContractAddress);
}

// Display available vehicles in `vehicleSelection.html`
async function displayVehicles() {
    const vehicleListDiv = document.getElementById('vehicleList');
    const vehicleCount = await dealerInstance.methods.vehicles.length().call();

    for (let i = 0; i < vehicleCount; i++) {
        const vehicle = await dealerInstance.methods.getVehicleDetails(i).call();
        const vehicleDiv = document.createElement('div');
        vehicleDiv.classList.add('vehicle');
        vehicleDiv.innerHTML = `
            <p><strong>Model:</strong> ${vehicle.model}</p>
            <p><strong>Price:</strong> ${vehicle.price}</p>
            <p><strong>Fuel Type:</strong> ${vehicle.fuelType}</p>
            <button onclick="buyVehicle(${i})">Buy</button>
        `;
        vehicleListDiv.appendChild(vehicleDiv);
    }
}

// Store selected vehicle ID and navigate to `ownerForm.html`
function buyVehicle(vehicleId) {
    sessionStorage.setItem('selectedVehicleId', vehicleId);
    window.location.href = 'ownerForm.html';
}

// Handle owner information submission in `ownerForm.html`
async function submitOwnerInfo(event) {
    event.preventDefault();

    const ownerName = document.getElementById('ownerName').value;
    const district = document.getElementById('district').value;
    const vehicleId = sessionStorage.getItem('selectedVehicleId');

    // Send transaction to register vehicle in Owner contract
    try {
        await ownerInstance.methods.registerVehicle(vehicleId, ownerName, district).send({ from: ethereum.selectedAddress });
        console.log("Vehicle registration submitted successfully.");
        window.location.href = 'rcBook.html';
    } catch (error) {
        console.error("Error during vehicle registration:", error);
        alert("Transaction failed. Please check the console for details.");
    }
}

// Display the generated RC Book in `rcBook.html`
async function displayRCBook() {
    try {
        const rcBook = await vehicleRegInstance.methods.getRCBookDetails(ethereum.selectedAddress).call();
        document.getElementById('rcOwnerName').textContent = rcBook.ownerName;
        document.getElementById('rcVehicleModel').textContent = rcBook.vehicleModel;
        document.getElementById('rcVehicleNumber').textContent = rcBook.vehicleNumber;
        document.getElementById('rcEngineNumber').textContent = rcBook.engineNumber;
        document.getElementById('rcChassisNumber').textContent = rcBook.chassisNumber;
        console.log("RC Book details displayed.");
    } catch (error) {
        console.error("Error retrieving RC Book details:", error);
        alert("Failed to retrieve RC Book details.");
    }
}

// Load Web3 when the page loads
window.addEventListener('load', loadWeb3);
