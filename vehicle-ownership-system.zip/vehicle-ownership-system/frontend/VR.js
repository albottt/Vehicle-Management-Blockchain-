import React, { useState, useEffect } from 'react';
import { ChevronLeft } from 'lucide-react';

// Main Landing Page Component
const LandingPage = ({ onNavigate }) => {
  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <h1 className="text-3xl font-bold text-center mb-8">Vehicle Registration Portal</h1>
          <div className="grid grid-cols-2 gap-6">
            <button
              onClick={() => onNavigate('vehicle-selection')}
              className="bg-blue-600 text-white rounded-lg p-8 text-xl font-semibold hover:bg-blue-700 transition-colors"
            >
              Vehicle Registration
            </button>
            <button
              className="bg-gray-600 text-white rounded-lg p-8 text-xl font-semibold hover:bg-gray-700 transition-colors"
            >
              Ownership Transfer
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Vehicle Selection Page Component
const VehicleSelectionPage = ({ onNavigate, onVehicleSelect }) => {
  const [vehicles, setVehicles] = useState([]);
  const [selectedVehicle, setSelectedVehicle] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadVehicles = async () => {
      try {
        if (window.ethereum) {
          const web3 = new Web3(window.ethereum);
          await window.ethereum.request({ method: 'eth_requestAccounts' });
          
          const dealerContract = new web3.eth.Contract(
            [
                {
                  "inputs": [],
                  "stateMutability": "nonpayable",
                  "type": "constructor"
                },
                {
                  "inputs": [
                    {
                      "internalType": "uint256",
                      "name": "",
                      "type": "uint256"
                    }
                  ],
                  "name": "vehicles",
                  "outputs": [
                    {
                      "internalType": "string",
                      "name": "model",
                      "type": "string"
                    },
                    {
                      "internalType": "uint256",
                      "name": "price",
                      "type": "uint256"
                    },
                    {
                      "internalType": "string",
                      "name": "fuelType",
                      "type": "string"
                    },
                    {
                      "internalType": "uint256",
                      "name": "yearOfManufacture",
                      "type": "uint256"
                    },
                    {
                      "internalType": "string",
                      "name": "engineNumber",
                      "type": "string"
                    },
                    {
                      "internalType": "string",
                      "name": "chassisNumber",
                      "type": "string"
                    },
                    {
                      "internalType": "uint256",
                      "name": "seatingCapacity",
                      "type": "uint256"
                    },
                    {
                      "internalType": "uint256",
                      "name": "unladenWeight",
                      "type": "uint256"
                    },
                    {
                      "internalType": "string",
                      "name": "color",
                      "type": "string"
                    }
                  ],
                  "stateMutability": "view",
                  "type": "function",
                  "constant": true
                },
                {
                  "inputs": [
                    {
                      "internalType": "uint256",
                      "name": "vehicleId",
                      "type": "uint256"
                    }
                  ],
                  "name": "getVehicleDetails",
                  "outputs": [
                    {
                      "components": [
                        {
                          "internalType": "string",
                          "name": "model",
                          "type": "string"
                        },
                        {
                          "internalType": "uint256",
                          "name": "price",
                          "type": "uint256"
                        },
                        {
                          "internalType": "string",
                          "name": "fuelType",
                          "type": "string"
                        },
                        {
                          "internalType": "uint256",
                          "name": "yearOfManufacture",
                          "type": "uint256"
                        },
                        {
                          "internalType": "string",
                          "name": "engineNumber",
                          "type": "string"
                        },
                        {
                          "internalType": "string",
                          "name": "chassisNumber",
                          "type": "string"
                        },
                        {
                          "internalType": "uint256",
                          "name": "seatingCapacity",
                          "type": "uint256"
                        },
                        {
                          "internalType": "uint256",
                          "name": "unladenWeight",
                          "type": "uint256"
                        },
                        {
                          "internalType": "string",
                          "name": "color",
                          "type": "string"
                        }
                      ],
                      "internalType": "struct Dealer.Vehicle",
                      "name": "",
                      "type": "tuple"
                    }
                  ],
                  "stateMutability": "view",
                  "type": "function",
                  "constant": true
                }
              ],
            '0x40467C5984c811CD359F9778D2389841cb8BbDA3'
          );

          const vehicle1 = await dealerContract.methods.getVehicleDetails(0).call();
          const vehicle2 = await dealerContract.methods.getVehicleDetails(1).call();
          setVehicles([vehicle1, vehicle2]);
        } else {
          console.error('Please install MetaMask!');
        }
        setLoading(false);
      } catch (error) {
        console.error('Error loading vehicles:', error);
        setLoading(false);
      }
    };

    loadVehicles();
  }, []);

  const handleVehicleClick = (vehicle) => {
    setSelectedVehicle(vehicle);
  };

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <div className="flex items-center mb-6">
            <button
              onClick={() => onNavigate('landing')}
              className="flex items-center text-blue-600 hover:text-blue-800"
            >
              <ChevronLeft className="w-5 h-5 mr-1" />
              Back
            </button>
          </div>
          
          <h2 className="text-2xl font-bold mb-6">Select a Vehicle</h2>
          
          {loading ? (
            <div className="text-center py-8">Loading vehicles...</div>
          ) : (
            <div className="grid grid-cols-2 gap-6">
              {vehicles.map((vehicle, index) => (
                <div
                  key={index}
                  onClick={() => handleVehicleClick(vehicle)}
                  className={`border rounded-lg p-6 cursor-pointer transition-all ${
                    selectedVehicle === vehicle
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-blue-300'
                  }`}
                >
                  <h3 className="text-xl font-semibold mb-4">{vehicle.model}</h3>
                  <div className="space-y-2 text-gray-600">
                    <p>Price: ${vehicle.price}</p>
                    <p>Fuel Type: {vehicle.fuelType}</p>
                    <p>Year: {vehicle.yearOfManufacture}</p>
                    <p>Color: {vehicle.color}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
          
          {selectedVehicle && (
            <div className="mt-8 flex justify-center">
              <button
                onClick={() => {
                  onVehicleSelect(selectedVehicle);
                  onNavigate('registration-form');
                }}
                className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Buy Selected Vehicle
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// Registration Form Component
const RegistrationForm = ({ selectedVehicle, onNavigate }) => {
  const [formData, setFormData] = useState({
    ownerName: '',
    district: '',
  });

  const districts = [
    'Trivandrum', 'Kollam', 'Pathanamthitta', 'Alappuzha', 'Kottayam',
    'Idukki', 'Ernakulam', 'Thrissur', 'Palakkad', 'Malappuram',
    'Kozhikkode', 'Wayanad', 'Kannur', 'Kasaragod'
  ];

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (window.ethereum) {
        const web3 = new Web3(window.ethereum);
        const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
        const ownerContract = new web3.eth.Contract(
            [
                {
                  "inputs": [
                    {
                      "internalType": "address",
                      "name": "_dealerAddress",
                      "type": "address"
                    },
                    {
                      "internalType": "address",
                      "name": "_registrationAgencyAddress",
                      "type": "address"
                    }
                  ],
                  "stateMutability": "nonpayable",
                  "type": "constructor"
                },
                {
                  "inputs": [],
                  "name": "dealerContract",
                  "outputs": [
                    {
                      "internalType": "contract Dealer",
                      "name": "",
                      "type": "address"
                    }
                  ],
                  "stateMutability": "view",
                  "type": "function",
                  "constant": true
                },
                {
                  "inputs": [],
                  "name": "ownerAddress",
                  "outputs": [
                    {
                      "internalType": "address",
                      "name": "",
                      "type": "address"
                    }
                  ],
                  "stateMutability": "view",
                  "type": "function",
                  "constant": true
                },
                {
                  "inputs": [],
                  "name": "registrationAgencyContract",
                  "outputs": [
                    {
                      "internalType": "contract VehicleRegistrationAgency",
                      "name": "",
                      "type": "address"
                    }
                  ],
                  "stateMutability": "view",
                  "type": "function",
                  "constant": true
                },
                {
                  "inputs": [
                    {
                      "internalType": "uint256",
                      "name": "vehicleId",
                      "type": "uint256"
                    },
                    {
                      "internalType": "string",
                      "name": "ownerName",
                      "type": "string"
                    },
                    {
                      "internalType": "string",
                      "name": "district",
                      "type": "string"
                    }
                  ],
                  "name": "registerVehicle",
                  "outputs": [],
                  "stateMutability": "nonpayable",
                  "type": "function"
                }
              ],
          '0xf9d7Ec9C8eed381401b8bdfc3CAE2437Ab41bce8'
        );

        await ownerContract.methods.registerVehicle(
          0, // vehicleId
          formData.ownerName,
          formData.district
        ).send({ from: accounts[0] });
        
        onNavigate('rc-book');
      }
    } catch (error) {
      console.error('Error registering vehicle:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <div className="flex items-center mb-6">
            <button
              onClick={() => onNavigate('vehicle-selection')}
              className="flex items-center text-blue-600 hover:text-blue-800"
            >
              <ChevronLeft className="w-5 h-5 mr-1" />
              Back
            </button>
          </div>

          <h2 className="text-2xl font-bold mb-6">Vehicle Registration Form</h2>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">
                Owner Name
              </label>
              <input
                type="text"
                required
                className="w-full p-2 border rounded-md"
                value={formData.ownerName}
                onChange={(e) => setFormData({...formData, ownerName: e.target.value})}
              />
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">
                District
              </label>
              <select
                required
                className="w-full p-2 border rounded-md"
                value={formData.district}
                onChange={(e) => setFormData({...formData, district: e.target.value})}
              >
                <option value="">Select District</option>
                {districts.map((district) => (
                  <option key={district} value={district}>
                    {district}
                  </option>
                ))}
              </select>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-3">Vehicle Details</h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <p>Model: {selectedVehicle.model}</p>
                <p>Price: ${selectedVehicle.price}</p>
                <p>Fuel Type: {selectedVehicle.fuelType}</p>
                <p>Year: {selectedVehicle.yearOfManufacture}</p>
                <p>Engine No: {selectedVehicle.engineNumber}</p>
                <p>Chassis No: {selectedVehicle.chassisNumber}</p>
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors"
            >
              Submit Registration
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

// RC Book Display Component
const RCBookDisplay = ({ vehicleData }) => {
  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-3xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <div className="border-4 border-blue-900 p-8 rounded-lg">
            <div className="text-center mb-8">
              <img
                src="/api/placeholder/100/100"
                alt="Government Emblem"
                className="mx-auto mb-4"
              />
              <h1 className="text-2xl font-bold text-blue-900">
                CERTIFICATE OF REGISTRATION
              </h1>
              <p className="text-gray-600">Government of Kerala</p>
            </div>

            <div className="grid grid-cols-2 gap-6 text-sm">
              <div className="space-y-4">
                <div>
                  <p className="font-semibold">Registration Number:</p>
                  <p>{vehicleData?.vehicleNumber}</p>
                </div>
                <div>
                  <p className="font-semibold">Owner Name:</p>
                  <p>{vehicleData?.ownerName}</p>
                </div>
                <div>
                  <p className="font-semibold">Vehicle Model:</p>
                  <p>{vehicleData?.vehicleModel}</p>
                </div>
                <div>
                  <p className="font-semibold">Engine Number:</p>
                  <p>{vehicleData?.engineNumber}</p>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <p className="font-semibold">Chassis Number:</p>
                  <p>{vehicleData?.chassisNumber}</p>
                </div>
                <div>
                  <p className="font-semibold">Fuel Type:</p>
                  <p>{vehicleData?.fuelType}</p>
                </div>
                <div>
                  <p className="font-semibold">Manufacturing Year:</p>
                  <p>{vehicleData?.yearOfManufacture}</p>
                </div>
                <div>
                  <p className="font-semibold">Color:</p>
                  <p>{vehicleData?.color}</p>
                </div>
              </div>
            </div>

            <div className="mt-8 pt-8 border-t border-gray-200">
              <div className="flex justify-between items-center">
                <div>
                  <p className="font-semibold">Date of Registration:</p>
                  <p>{new Date().toLocaleDateString()}</p>
                </div>
                <div className="text-center">
                  <img
                    src="/api/placeholder/150/60"
                    alt="Digital Signature"
                    className="mb-2"
                  />
                  <p className="font-semibold">Registering Authority</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Main App Component
const App = () => {
  const [currentPage, setCurrentPage] = useState('landing');
  const [selectedVehicle, setSelectedVehicle] = useState(null);
  const [rcBookData, setRcBookData] = useState(null);

  const handleNavigation = (page) => {
    setCurrentPage(page);
  };

  const handleVehicleSelect = (vehicle) => {
    setSelectedVehicle(vehicle);
  };

  return (
    <div>
      {currentPage === 'landing' && (
        <LandingPage onNavigate={handleNavigation} />
      )}
      {currentPage === 'vehicle-selection' && (
        <VehicleSelectionPage
          onNavigate={handleNavigation}
          onVehicleSelect={handleVehicleSelect}
        />
      )}
      {currentPage === 'registration-form' && (
        <RegistrationForm
          selectedVehicle={selectedVehicle}
          onNavigate={handleNavigation}
        />
      )}
      {currentPage === 'rc-book' && (
        <RCBookDisplay vehicleData={rcBookData} />
      )}
    </div>
  );
};

export default App;