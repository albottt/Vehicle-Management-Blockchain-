const Dealer = artifacts.require("Dealer");
const VehicleRegistrationAgency = artifacts.require("VehicleRegistrationAgency");
const Owner = artifacts.require("Owner");

module.exports = async function (deployer, network, accounts) {
    // Deploy Dealer contract
    await deployer.deploy(Dealer);
    const dealerInstance = await Dealer.deployed();
    console.log("Dealer deployed to:", dealerInstance.address);

    // Deploy VehicleRegistrationAgency contract
    await deployer.deploy(VehicleRegistrationAgency);
    const registrationAgencyInstance = await VehicleRegistrationAgency.deployed();
    console.log("VehicleRegistrationAgency deployed to:", registrationAgencyInstance.address);

    // Deploy Owner contract, using the addresses of the Dealer and VehicleRegistrationAgency contracts
    await deployer.deploy(
        Owner,
        dealerInstance.address,
        registrationAgencyInstance.address
    );
    const ownerInstance = await Owner.deployed();
    console.log("Owner deployed to:", ownerInstance.address);
};
